<?php $pageScript = 'subjects'; ?>
<div class="card">
  <div class="toolbar">
    <div class="spacer"></div>
    <button class="btn primary" id="btn-add">＋ Add Subject</button>
  </div>
  <div id="table"></div>
</div>

<template id="tpl-form">
  <form id="subject-form">
    <div class="form-row">
      <div><label>Subject Code *</label><input type="text" name="subject_code" required maxlength="30"></div>
      <div><label>Units *</label><input type="number" name="units" step="0.5" min="0.5" value="1.0" required></div>
    </div>
    <label>Subject Name *</label><input type="text" name="name" required maxlength="120">
    <label>Description</label><input type="text" name="description" maxlength="255">
    <label>Status *</label>
    <select name="status"><option value="active">Active</option><option value="archived">Archived</option></select>
  </form>
</template>
