<?php $pageScript = 'security'; ?>
<div id="summary" class="grid cols-4"></div>

<div class="card">
  <div class="toolbar">
    <select id="f-severity">
      <option value="">All severities</option>
      <option value="low">Low</option><option value="medium">Medium</option>
      <option value="high">High</option><option value="critical">Critical</option>
    </select>
    <select id="f-resolved">
      <option value="">All</option>
      <option value="0">Unresolved</option>
      <option value="1">Resolved</option>
    </select>
    <div class="spacer"></div>
    <button class="btn danger" id="btn-block">Block IP</button>
  </div>
  <h3>Security Events</h3>
  <div id="table"></div>
  <div id="pager"></div>
</div>

<div class="card">
  <h3>Blocked IP Addresses</h3>
  <div id="blocked-table"></div>
</div>

<template id="tpl-block">
  <form id="block-form">
    <label>IP Address *</label><input type="text" name="ip_address" required maxlength="45">
    <label>Reason *</label><input type="text" name="reason" required maxlength="255">
  </form>
</template>

<template id="tpl-resolve">
  <form id="resolve-form">
    <label>Resolution Notes</label>
    <textarea name="notes" rows="3" maxlength="500"></textarea>
  </form>
</template>
