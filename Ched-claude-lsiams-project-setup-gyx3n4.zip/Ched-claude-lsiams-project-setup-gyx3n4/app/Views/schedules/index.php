<?php
$pageScript = 'schedules';
$isAdmin = ($currentUser['role_name'] ?? '') === 'Administrator';
?>
<div class="card">
  <div class="toolbar">
    <select id="f-day">
      <option value="">All days</option>
      <option value="1">Monday</option><option value="2">Tuesday</option>
      <option value="3">Wednesday</option><option value="4">Thursday</option>
      <option value="5">Friday</option><option value="6">Saturday</option>
      <option value="7">Sunday</option>
    </select>
    <?php if ($isAdmin): ?>
      <select id="f-teacher">
        <option value="">All teachers</option>
        <?php foreach ($teachers as $t): ?>
          <option value="<?= $e($t['id']) ?>"><?= $e($t['last_name'] . ', ' . $t['first_name']) ?></option>
        <?php endforeach; ?>
      </select>
      <select id="f-room">
        <option value="">All rooms</option>
        <?php foreach ($classrooms as $c): ?>
          <option value="<?= $e($c['id']) ?>"><?= $e($c['room_number']) ?></option>
        <?php endforeach; ?>
      </select>
    <?php endif; ?>
    <div class="spacer"></div>
    <?php if ($isAdmin): ?>
      <button class="btn primary" id="btn-add">＋ Add Schedule</button>
    <?php endif; ?>
  </div>
  <div id="table"></div>
</div>

<?php if ($isAdmin): ?>
<template id="tpl-form">
  <form id="schedule-form">
    <div class="form-row">
      <div><label>Teacher *</label>
        <select name="teacher_id" required>
          <?php foreach ($teachers as $t): ?>
            <option value="<?= $e($t['id']) ?>"><?= $e($t['last_name'] . ', ' . $t['first_name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label>Subject *</label>
        <select name="subject_id" required>
          <?php foreach ($subjects as $s): ?>
            <option value="<?= $e($s['id']) ?>"><?= $e($s['subject_code'] . ' — ' . $s['name']) ?></option>
          <?php endforeach; ?>
        </select></div>
    </div>
    <div class="form-row">
      <div><label>Section *</label>
        <select name="section_id" required>
          <?php foreach ($sections as $s): ?>
            <option value="<?= $e($s['id']) ?>"><?= $e($s['grade_name'] . ' — ' . $s['name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label>Classroom *</label>
        <select name="classroom_id" required>
          <?php foreach ($classrooms as $c): ?>
            <option value="<?= $e($c['id']) ?>"><?= $e($c['room_number']) ?></option>
          <?php endforeach; ?>
        </select></div>
    </div>
    <div class="form-row">
      <div><label>Day *</label>
        <select name="day_of_week" required>
          <option value="1">Monday</option><option value="2">Tuesday</option>
          <option value="3">Wednesday</option><option value="4">Thursday</option>
          <option value="5">Friday</option><option value="6">Saturday</option>
          <option value="7">Sunday</option>
        </select></div>
      <div><label>Start *</label><input type="time" name="start_time" required></div>
      <div><label>End *</label><input type="time" name="end_time" required></div>
    </div>
    <div class="form-row">
      <div><label>Attendance Window (min) *</label>
        <input type="number" name="attendance_window_minutes" min="1" max="120" value="20" required></div>
      <div><label>Late Threshold (min) *</label>
        <input type="number" name="late_threshold_minutes" min="1" max="120" value="20" required></div>
    </div>
    <p class="text-dim" style="font-size:12px;">
      Teacher and classroom conflicts are rejected automatically.
    </p>
  </form>
</template>
<?php endif; ?>
