<?php $pageScript = 'teachers'; ?>
<div class="card">
  <div class="toolbar">
    <input type="text" id="search" placeholder="Search name, employee number, department…">
    <div class="spacer"></div>
    <button class="btn primary" id="btn-add">＋ Add Teacher</button>
  </div>
  <div id="table"></div>
  <div id="pager"></div>
</div>

<template id="tpl-form">
  <form id="teacher-form" enctype="multipart/form-data">
    <div class="form-row">
      <div><label>Employee Number *</label><input type="text" name="employee_number" required maxlength="30"></div>
      <div><label>Department</label><input type="text" name="department" maxlength="100"></div>
    </div>
    <div class="form-row">
      <div><label>First Name *</label><input type="text" name="first_name" required maxlength="80"></div>
      <div><label>Middle Name</label><input type="text" name="middle_name" maxlength="80"></div>
      <div><label>Last Name *</label><input type="text" name="last_name" required maxlength="80"></div>
    </div>
    <div class="form-row">
      <div><label>Email *</label><input type="email" name="email" required maxlength="150"></div>
      <div><label>Phone</label><input type="text" name="phone" maxlength="30"></div>
    </div>
    <div class="form-row new-only">
      <div><label>Username *</label><input type="text" name="username" maxlength="60"></div>
      <div><label>Temporary Password *</label><input type="password" name="password" maxlength="255"
        placeholder="min 12 chars, upper/lower/number"></div>
    </div>
    <div class="edit-only" style="display:none;">
      <label>Status *</label>
      <select name="status"><option value="active">Active</option><option value="inactive">Inactive</option><option value="archived">Archived</option></select>
    </div>
    <label>Assigned Subjects</label>
    <select name="subject_ids[]" multiple size="4">
      <?php foreach ($subjects as $s): ?>
        <option value="<?= $e($s['id']) ?>"><?= $e($s['subject_code'] . ' — ' . $s['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <label>Photo (JPG/PNG, max 2 MB)</label><input type="file" name="photo" accept=".jpg,.jpeg,.png">
    <p class="text-dim" style="font-size:12px;">
      Fingerprint enrollment is done afterwards from the <a href="/fingerprints">Fingerprints</a> module.
    </p>
  </form>
</template>
