<?php $pageScript = 'students'; ?>
<div class="card">
  <div class="toolbar">
    <input type="text" id="search" placeholder="Search name, number, RFID…">
    <select id="f-status">
      <option value="">All statuses</option>
      <option value="active">Active</option>
      <option value="inactive">Inactive</option>
      <option value="archived">Archived</option>
    </select>
    <select id="f-section">
      <option value="">All sections</option>
      <?php foreach ($sections as $s): ?>
        <option value="<?= $e($s['id']) ?>"><?= $e($s['grade_name'] . ' — ' . $s['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select id="f-grade">
      <option value="">All grades</option>
      <?php foreach ($grades as $g): ?>
        <option value="<?= $e($g['id']) ?>"><?= $e($g['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <div class="spacer"></div>
    <button class="btn" id="btn-import">Import CSV</button>
    <button class="btn" id="btn-export">Export</button>
    <button class="btn primary" id="btn-add">＋ Add Student</button>
  </div>
  <div id="table"></div>
  <div id="pager"></div>
</div>

<template id="tpl-form">
  <form id="student-form" enctype="multipart/form-data">
    <div class="form-row">
      <div><label>Student Number *</label><input type="text" name="student_number" required maxlength="30"></div>
      <div><label>RFID UID (optional)</label><input type="text" name="rfid_uid" maxlength="32" placeholder="hex UID from card"></div>
    </div>
    <div class="form-row">
      <div><label>First Name *</label><input type="text" name="first_name" required maxlength="80"></div>
      <div><label>Middle Name</label><input type="text" name="middle_name" maxlength="80"></div>
      <div><label>Last Name *</label><input type="text" name="last_name" required maxlength="80"></div>
    </div>
    <div class="form-row">
      <div><label>Gender *</label>
        <select name="gender" required><option value="male">Male</option><option value="female">Female</option></select></div>
      <div><label>Birthdate</label><input type="date" name="birthdate"></div>
      <div><label>Status *</label>
        <select name="status"><option value="active">Active</option><option value="inactive">Inactive</option><option value="archived">Archived</option></select></div>
    </div>
    <div class="form-row">
      <div><label>Grade Level</label>
        <select name="grade_level_id"><option value="">—</option>
          <?php foreach ($grades as $g): ?><option value="<?= $e($g['id']) ?>"><?= $e($g['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div><label>Section</label>
        <select name="section_id"><option value="">—</option>
          <?php foreach ($sections as $s): ?><option value="<?= $e($s['id']) ?>"><?= $e($s['grade_name'] . ' — ' . $s['name']) ?></option><?php endforeach; ?>
        </select></div>
    </div>
    <label>Email</label><input type="email" name="email" maxlength="150">
    <label>Address</label><input type="text" name="address" maxlength="255">
    <div class="form-row">
      <div><label>Guardian Name</label><input type="text" name="guardian_name" maxlength="150"></div>
      <div><label>Guardian Contact</label><input type="text" name="guardian_contact" maxlength="30"></div>
    </div>
    <label>Photo (JPG/PNG, max 2 MB)</label><input type="file" name="photo" accept=".jpg,.jpeg,.png">
  </form>
</template>

<template id="tpl-import">
  <form id="import-form" enctype="multipart/form-data">
    <p class="text-dim" style="font-size:12.5px;">
      CSV header must be exactly:<br>
      <span class="mono">student_number,first_name,middle_name,last_name,gender,birthdate,guardian_name,guardian_contact,rfid_uid</span><br>
      The whole import rolls back if any row is invalid or duplicated.
    </p>
    <label>CSV File</label><input type="file" name="file" accept=".csv" required>
  </form>
</template>
