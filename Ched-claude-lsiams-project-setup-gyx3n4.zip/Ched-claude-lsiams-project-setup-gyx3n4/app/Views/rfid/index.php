<?php $pageScript = 'rfid'; ?>
<div class="card">
  <div class="toolbar">
    <input type="text" id="search" placeholder="Search UID, student…">
    <div class="spacer"></div>
    <button class="btn" id="btn-unknown">Unknown Cards</button>
    <button class="btn primary" id="btn-add">＋ Register Card</button>
  </div>
  <div id="table"></div>
  <div id="pager"></div>
</div>

<template id="tpl-form">
  <form id="rfid-form">
    <label>Student ID *</label>
    <input type="number" name="student_id" required min="1" placeholder="internal student id (see Students page)">
    <label>RFID UID * (hex)</label>
    <input type="text" name="uid" required maxlength="32" placeholder="e.g. 04A7C1935D">
    <p class="text-dim" style="font-size:12px;">One active card per student; UIDs must be unique.</p>
  </form>
</template>

<template id="tpl-replace">
  <form id="replace-form">
    <label>New RFID UID * (hex)</label>
    <input type="text" name="uid" required maxlength="32">
    <p class="text-dim" style="font-size:12px;">
      The old card is deactivated; attendance history is preserved.
    </p>
  </form>
</template>
